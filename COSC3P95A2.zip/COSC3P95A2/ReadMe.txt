Steve Mastrokalos
COSC 3P95 Assignment 2
I wasn't able to do most of the assignment
I have never networked before, it was not covered in any prereq
Took over a week to get the server working. 
My files are on my github.

https://github.com/vestex727/COSC-3P95

File Assignment 2