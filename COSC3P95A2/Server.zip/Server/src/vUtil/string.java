/**My personal String utility class
 *
 */

package vUtil;

public class string {
    public static final String alpha = "abcdefghijklmnopqrstuvwxyz";
    java.util.Random randy;

    /**Splits a string into 2 halves, each put into a 2 element array
     * halves[0] = first half of the string
     * halves[1] =
     *
     * @param input String to be cut in half
     * @return
     */
    String[] halves(String input){
        int delta = (int) java.lang.Math.floor(input.length()/2);
        String front = "";
        String back = "";

        for(int i = 0; i < delta; i++)
        {
            front += input.charAt(i);
        }
        for(int i = delta; i < input.length(); i++){
            back +=input.charAt(i);
        }

        String[] array = {front, back};

        return array;
    }

    /**Finds the number of characters different in 2 strings of equal length
     *
     * @param a First string to be compared
     * @param b Second string to be compared
     * @return  The number of characters different between the 2 strings
     */
    int differencesInString(String a, String b){
        int counter = 0;
        for(int i = 0; i < a.length() && i < b.length(); i++) {
            if(a!=b) counter++;
        }
        return counter;
    }

    public static String alphaAt(int index){return String.valueOf(alphAt(index));}

    /**Gets character of alphabet at index
     *
     * @param index
     * @return
     */
    public static char alphAt(int index){return alpha.charAt(index);}

    /**Gets random lowercase letter of the alphabet
     *
     * @return  Random lowercase letter     */
    public char getRandomLetterLower(){return alphAt(randy.nextInt(26));}
}
