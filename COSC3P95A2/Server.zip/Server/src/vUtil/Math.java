package vUtil;

public class Math {
}
