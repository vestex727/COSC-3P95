/**Creates txt files of various sizes
 * Good for testing stuff
 * @Author Steve Mastrokalos 7276900
 *
 */
package vUtil.File;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class createTXT {
    FileWriter writer;
    File output;
    Random randy;
    int letterNum;

    createTXT() {
        String nameList = "";
        randy = new Random();
        for(int i = 0; i < 20; i++) {
            letterNum = i;
            if(i >= 3) {
                int n = randy.nextInt(1023) + 1;
                String temp = n + "KB";
                nameList += "\"" + temp + "\", ";
                setUpWriter(temp);
                nKBsOfTXT(n);
                endWriter();
            }else{
                int n = randy.nextInt(8) + 1;
                String temp = n + "MB";
                nameList += "\"" + temp + "\", ";
                setUpWriter(temp);
                nMBsOfTXT(n);
                endWriter();
            }
        }
        nameList = nameList.trim();
        System.out.println(nameList);
    }

    void nBlankBytesOfText(int n, Boolean MB){
        if(MB) nMBsOfTXT(n);
        else nKBsOfTXT(n);
    }

    void nMBsOfTXT(int n) {
        for (int i = 0; i < n; i++) createMBofTXT();
    }

    void createMBofTXT() {
        nKBsOfTXT(1024);
    }

    void nKBsOfTXT(int n) {
        for (int i = 0; i < n; i++) createKilobyteOfTXT();
    }

    void createKilobyteOfTXT() {for(int i = 0; i < 1024; i++) output(vUtil.string.alphaAt(letterNum));}

    /**
     * Sets up the file writer with the given file name
     *
     * @param fileName Name of the output file
     */
    void setUpWriter(String fileName) {
        try {
            output = new File(fileName);
            writer = new FileWriter(fileName);
        } catch (IOException e) {
        }
    }

    /**Outputs the inputted parameter to output file
     *
     * @param out output
     */
    void output(String out) {
        try {
            writer.write(out + "\n");
        } catch (IOException e) {

        }
    }

    /**Closes the writer
     *
     */
    void endWriter() {
        try {
            writer.close();
        } catch (IOException e) {
        }
    }

    public static void main(String[] args){
        createTXT ct = new createTXT();
    }
}
