/**Encryption Exception extention
 *Does what it says on the tin
 */
package vUtil.Encryption;

/**Exception class for Encryption class
 * Only really one way to do this   */
public class EncryptionException extends Exception {

    /**Exception for encryption failure     */
    public EncryptionException() {}

    /** Exception for encryption failure
     *
     * @param message   Message to send on failure
     * @param throwable Part of extending an exception      */
    public EncryptionException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
