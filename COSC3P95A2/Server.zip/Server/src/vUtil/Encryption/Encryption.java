/** A utility class that encrypts or decrypts a file.
 *  Part of my personal utility library
 *
 *
 * @author Steve Mastrokalos, based on code from www.codejava.net   */
package vUtil.Encryption;

import java.io.*;
import java.security.*;

import javax.crypto.*;

public class Encryption {

    /**Creates an encrypted file from a given unencrypted file
     *
     * @param key   Encryption key
     * @param inputFile File to be encrypted
     * @return  Encrypted File
     * @throws EncryptionException  */
    public static File encrypt(String key, File inputFile) throws EncryptionException {
        try{
            File output = File.createTempFile("tempEncyptionFile", "");
            encrypt(key, inputFile, output);
            return output;
        }catch(IOException e){

        }
        return null;
    }

    /**Creates an encrypted file from a given unencrypted file
     *
     * @param key   Encryption key
     * @param inputFile File to be encrypted
     * @return  Encrypted File
     * @throws EncryptionException  */
    public static File decrypt(String key, File inputFile) throws EncryptionException {
        try{
            File output = File.createTempFile("tempDecryptionFile","");
            decrypt(key, inputFile, output);
            return output;
        }catch(IOException e){

        }
        return null;
    }

    /**Encrypts a file into into the output file
     *
     * @param key   Encryption key
     * @param inputFile File to encrypt
     * @param outputFile    Location to send encrypted File
     * @throws EncryptionException     */
    public static void encrypt(String key, File inputFile, File outputFile) throws EncryptionException {crypt(Cipher.ENCRYPT_MODE, key, inputFile, outputFile);}

    /**Decryptes a file to the output file
     *
     * @param key   Encryption key
     * @param inputFile File to decrypt
     * @param outputFile    Location to put decrypted File
     * @throws EncryptionException  */
    public static void decrypt(String key, File inputFile, File outputFile) throws EncryptionException {crypt(Cipher.DECRYPT_MODE, key, inputFile, outputFile);}

    /**Encrypts or decrypts a file
     *
     * @param cipherMode    Encryption vs Decryption modes
     * @param key           Encryption key
     * @param inputFile     File to be en/decrypted
     * @param outputFile    Output file
     * @throws EncryptionException  Exception in case en/decryption fails   */
    private static void crypt(int cipherMode, String key, File inputFile, File outputFile) throws EncryptionException {
        try {
            //Sets up encoding/decoding algorithm
            String algo = "AES";
            Key cryptKey = new javax.crypto.spec.SecretKeySpec(key.getBytes(), algo);
            Cipher cipher = Cipher.getInstance(algo);
            cipher.init(cipherMode, cryptKey);

            //en/decodes input
            FileInputStream inputStream = new FileInputStream(inputFile);
            byte[] inputBytes = new byte[(int)inputFile.length()];
            inputStream.read(inputBytes);


            //Outputs result
            byte[] outputBytes = cipher.doFinal(inputBytes);

            FileOutputStream outputStream = new FileOutputStream(outputFile);
            outputStream.write(outputBytes);

            //Closes streams
            inputStream.close();
            outputStream.close();
        } catch (NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | NoSuchAlgorithmException | BadPaddingException | IOException type) { //Catches any of the many possible exceptions
            throw new EncryptionException("Error during en/decryption of files", type);
        }
    }
}

