package vUtil;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class writer {
    FileWriter writer;
    File output;

    writer(String fileName) {
        //if(fileName == null)throw new IOException("fileName is null");
        try {
            output = new File(fileName);
            writer = new FileWriter(fileName);
        } catch (IOException e) {
            //throw Exception("Setting up new writer failed.");
        }
    }
}
