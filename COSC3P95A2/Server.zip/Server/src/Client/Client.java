/**A client class that creates client objects that send encrypted files to a server
 *
 * @author Steve Mastrokalos
 */
package Client;

import vUtil.Encryption.Encryption;

import java.io.*;
import java.net.Socket;

public class Client {
    private static DataOutputStream dataOutputStream = null;
    private static DataInputStream dataInputStream = null;
    private static final String[] FILE_NAMES = {"6MB", "8MB", "7MB", "445KB", "599KB", "408KB", "229KB", "233KB", "532KB", "443KB", "1003KB", "238KB", "802KB", "785KB", "817KB", "143KB", "904KB", "14KB", "209KB", "698KB"};

    /**Runs a client that will send a file to the server
     *
     * @param host
     * @param port
     * @param fileNumber
     */
    Client(String host, int port, int fileNumber){
        String filePath = FILE_NAMES[fileNumber];
        Client c = new Client(host, port, filePath);
    }
    Client(String host, int port, String filePath){
        try (Socket socket = new Socket(host, port)) {

            dataInputStream = new DataInputStream(socket.getInputStream());
            dataOutputStream = new DataOutputStream(socket.getOutputStream());
            System.out.println("Sending " + filePath + " to the Server");

            sendFile(filePath);

            dataInputStream.close();
            dataOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**Sends encrypted files to server in chunks
     * Two of my advanced features
     *
     * @param path  Path of file to be sent
     * @throws Exception        */
    private static void sendFile(String path) throws Exception {
        int bytes = 0;
        File file = new File(path); //gets file that will be sent
        FileInputStream fileInputStream = new FileInputStream(Encryption.encrypt("KingdomHeartsIII", file));    //Gets input stream from encrypted file (The key is one of my favorite games, worked out to 16 characters nicely)

        dataOutputStream.writeLong(file.length());  //Sending file

        //File gets chunked here, one of the advanced features
        byte[] buffer = new byte[4 * 1024];
        while ((bytes = fileInputStream.read(buffer)) != -1) {  //Sends the chunky goodness to the server socket
            dataOutputStream.write(buffer, 0, bytes);
            dataOutputStream.flush();
        }

        fileInputStream.close();
    }
}

