package Client;

/**Controls and runs multiple clients simultaniously (So I don't need to start multiple client objects myself)
 *
 * @Author Steve Mastrokalos 7276900 */
public class ClientControl {
    Client[] clients;
    ClientControl(int numberOfClients){createClients(numberOfClients);}

    /**Defaults to sending the clients to port 727 (part of my Student ID)
     *
     * @param numOfClients  Number of clients to create
     */
    void createClients(int numOfClients){createClients("localhost", 727, numOfClients);}

    /**Creates clients to send files to the given host and port
     *
     * @param host  Host IP
     * @param port  Port number
     * @param numOfClients  Number of clients to create
     */
    void createClients(String host, int port, int numOfClients){
        clients = new Client[numOfClients];
        for(int i = 0; i < numOfClients; i++){
            new Client(host, port, i);
        }
    }

    //Runs 20 clients
    public static void main(String[] args) {ClientControl c = new ClientControl(20);}
}
