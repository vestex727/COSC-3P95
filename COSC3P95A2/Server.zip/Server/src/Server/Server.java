/**Server class
 * Recieves and stores files
 *
 * @author Steve Mastrokalos 7276900
 */
package Server;

import java.net.*;
import java.io.*;
import java.util.concurrent.Semaphore;

public class Server {
    private ServerSocket serverSocket;
    public int counter = 0;
    public static Semaphore semaphore;

    /**Creates server with a maximum number of allowed active clients at once
     * The rate limitation/alt threading is one of my advanced features
     *
     * @param maxClients    max active clients allowed at once
     */
    Server(int maxClients){
        semaphore = new Semaphore(maxClients);   //Creates a server with a limit of 5 active clients at a time
    }

    /**Starts the server on given port
     *
     * @param port  Port to recieve data from */
    public void start(int port){
        try {
            serverSocket = new ServerSocket(port);
            while(true){
                new ClientHandler(serverSocket.accept(), counter).start();
                System.out.println(semaphore.availablePermits());
                counter++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            stop();
        }
    }

    /**Ends the connection to a client
     * (Specifically closes the socket the client connected to)
     *
     */
    public void stop() {
        try {
            serverSocket.close ();
        } catch (IOException e) {
            e.printStackTrace ();
        }
    }

    /**Starts server on  port 727, with 5 clients max
     *
     * @param args
     */
    public static void main(String[] args) {
        Server server = new Server(5);
        server.start(727);
    }

}
