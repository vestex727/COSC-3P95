/**client handler class for server
 * Can handle multiple clients at once through multithreading
 *
 * @author Steve Mastrokalos 7276900     */
package Server;

import java.io.*;
import java.net.Socket;

/**Creates a multithreaded client handler
 *Allows server to deal with multiple clients at once
 *
 */
public class ClientHandler extends Thread {
    private Socket clientSocket;
    private DataOutputStream out;
    private DataInputStream in;
    int counter;

    /**Runs the thread when sephamore is free
     *
     * @param socket
     * @param fileNumber
     */
    public ClientHandler(Socket socket, int fileNumber) {
        while(!Server.semaphore.tryAcquire()){}
        this.clientSocket = socket;
        counter = fileNumber;
    }

    /**Runs the thread
     * Recieves the files from the clients
     *
     */
    public void run(){
        try {
            out = new DataOutputStream(clientSocket.getOutputStream());
            in = new DataInputStream(clientSocket.getInputStream());
            receiveFile("File" + counter + ".txt", in);

            clientSocket.close();

            in.close ();
            out.close ();
            Server.semaphore.release();

        } catch (IOException e) {

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**Recives the files in chunks
     * Saves as a whole
     *
     * @param fileName
     * @param input
     * @throws Exception
     */
    private static void receiveFile(String fileName, DataInputStream input) throws Exception {
        int bytes = 0;
        FileOutputStream fileOutputStream = new FileOutputStream(fileName);

        long size = input.readLong(); // read file size
        byte[] buffer = new byte[4 * 1024]; //prepares buffer for dechunking
        while (size > 0 && (bytes = input.read(buffer, 0, (int) Math.min(buffer.length, size))) != -1) {
            //Writes in new file dechunked file
            fileOutputStream.write(buffer, 0, bytes);
            size -= bytes;
        }

        //Prints ot console job done
        System.out.println("File Received");
        fileOutputStream.close();
    }
}
